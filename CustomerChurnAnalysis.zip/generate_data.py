"""
generate_data.py
Indian telecom customer churn dataset.
Run: python generate_data.py
"""
import pandas as pd
import numpy as np

np.random.seed(42)
n = 1000

tenure = np.random.randint(1, 73, n)
# Indian telecom plans: Rs 199 to Rs 999/month
monthly_charges = np.round(np.random.choice([199, 299, 399, 499, 599, 699, 799, 999], n).astype(float)
                            + np.random.uniform(-20, 20, n), 2)
total_charges = np.round(tenure * monthly_charges + np.random.normal(0, 200, n), 2)
total_charges = np.clip(total_charges, 0, None)

churn_prob = (
    0.45 * (tenure < 12).astype(float) +
    0.30 * (monthly_charges > 599).astype(float) +
    np.random.uniform(0, 0.28, n)
)
churn = (churn_prob > 0.58).astype(int)

df = pd.DataFrame({
    "customer_id":       [f"IND-CUST-{i:04d}" for i in range(n)],
    "gender":            np.random.choice(["Male", "Female"], n),
    "senior_citizen":    np.random.choice([0, 1], n, p=[0.82, 0.18]),
    "partner":           np.random.choice(["Yes", "No"], n),
    "dependents":        np.random.choice(["Yes", "No"], n, p=[0.35, 0.65]),
    "tenure_months":     tenure,
    "phone_service":     np.random.choice(["Yes", "No"], n, p=[0.92, 0.08]),
    "multiple_lines":    np.random.choice(["No", "Yes", "No phone service"], n),
    "internet_service":  np.random.choice(["4G", "Fiber", "No"], n, p=[0.40, 0.42, 0.18]),
    "online_security":   np.random.choice(["Yes", "No", "No internet"], n),
    "streaming":         np.random.choice(["Yes", "No", "No internet"], n),
    "contract_type":     np.random.choice(["Prepaid Monthly", "Annual Plan", "2-Year Plan"],
                                           n, p=[0.58, 0.28, 0.14]),
    "paperless_billing": np.random.choice(["Yes", "No"], n),
    "payment_method":    np.random.choice(["UPI", "Net Banking", "Credit Card", "Debit Card"], n),
    "monthly_charge_inr": monthly_charges,
    "total_charge_inr":   total_charges,
    "churn":             ["Yes" if c else "No" for c in churn],
})

df.to_csv("data/telecom_churn.csv", index=False)
print(f"Dataset saved: {len(df)} rows | Churn rate: {churn.mean()*100:.1f}%")
print(f"Avg monthly charge: Rs {monthly_charges.mean():.0f}")
