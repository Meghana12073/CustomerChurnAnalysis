"""
churn_analysis.py
Customer Churn Analysis and BI Dashboard
Indian telecom dataset: 1,000 records, EDA, classification, stakeholder dashboard.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.preprocessing import LabelEncoder, StandardScaler
import warnings
warnings.filterwarnings("ignore")

# ── 1. LOAD ───────────────────────────────────────────────────────────────────
df = pd.read_csv("data/telecom_churn.csv")
print(f"Shape: {df.shape}")
print(f"Missing values:\n{df.isnull().sum()}")
df["churn_bin"] = (df["churn"] == "Yes").astype(int)

# ── 2. EDA ────────────────────────────────────────────────────────────────────
churn_rate = df["churn_bin"].mean() * 100
print(f"\nOverall churn rate: {churn_rate:.1f}%")

df["tenure_group"] = pd.cut(df["tenure_months"],
                             bins=[0, 12, 24, 48, 72],
                             labels=["0-12m", "13-24m", "25-48m", "49-72m"])
churn_by_tenure   = df.groupby("tenure_group")["churn_bin"].mean() * 100
churn_by_contract = df.groupby("contract_type")["churn_bin"].mean() * 100
churn_by_payment  = df.groupby("payment_method")["churn_bin"].mean() * 100

avg_charge_churned  = df[df["churn_bin"] == 1]["monthly_charge_inr"].mean()
avg_charge_retained = df[df["churn_bin"] == 0]["monthly_charge_inr"].mean()

# Monthly revenue at risk from churned customers
monthly_rev_at_risk = df[df["churn_bin"] == 1]["monthly_charge_inr"].sum()

print(f"Churn by tenure:\n{churn_by_tenure.round(1)}")
print(f"\nChurn by contract:\n{churn_by_contract.round(1)}")
print(f"\nAvg charge — churned: Rs {avg_charge_churned:.0f} | retained: Rs {avg_charge_retained:.0f}")
print(f"Monthly revenue at risk from churned customers: Rs {monthly_rev_at_risk:,.0f}")

# ── 3. FEATURE ENGINEERING ───────────────────────────────────────────────────
df_model = df.copy()
cat_cols = ["gender", "partner", "dependents", "phone_service", "multiple_lines",
            "internet_service", "online_security", "streaming",
            "paperless_billing", "payment_method", "tenure_group"]
le = LabelEncoder()
for col in cat_cols:
    df_model[col] = le.fit_transform(df_model[col].astype(str))

contract_map = {"Prepaid Monthly": 0, "Annual Plan": 1, "2-Year Plan": 2}
df_model["contract_type"] = df_model["contract_type"].map(contract_map)
df_model["charge_log"] = np.log1p(df_model["monthly_charge_inr"])

features = ["gender", "senior_citizen", "partner", "dependents", "tenure_months",
            "phone_service", "multiple_lines", "internet_service", "online_security",
            "streaming", "contract_type", "paperless_billing", "payment_method",
            "monthly_charge_inr", "total_charge_inr", "charge_log"]
X = df_model[features]
y = df_model["churn_bin"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

sc = StandardScaler()
X_tr_s = sc.fit_transform(X_train)
X_te_s  = sc.transform(X_test)

lr  = LogisticRegression(max_iter=1000, random_state=42)
lr.fit(X_tr_s, y_train)
lr_auc = roc_auc_score(y_test, lr.predict_proba(X_te_s)[:, 1])

rf  = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)
rf_auc   = roc_auc_score(y_test, rf.predict_proba(X_test)[:, 1])

print(f"\n=== LOGISTIC REGRESSION ROC-AUC: {lr_auc:.3f} ===")
print(f"=== RANDOM FOREST ROC-AUC: {rf_auc:.3f} ===")
print(f"\nRandom Forest Classification Report:")
print(classification_report(y_test, rf_preds, target_names=["Retained", "Churned"]))

importances = pd.Series(rf.feature_importances_, index=features).sort_values(ascending=False)

# ── 4. DASHBOARD ──────────────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 2, figsize=(12, 9))
fig.suptitle("Customer Churn Analysis Dashboard — Indian Telecom", fontsize=13, fontweight="bold")

# Plot 1: Churn distribution
counts = df["churn"].value_counts()
axes[0, 0].bar(["Retained", "Churned"], counts.values, color=["#2a78d6", "#e34948"])
axes[0, 0].set_title("Churn Distribution")
axes[0, 0].set_ylabel("Customers")
for i, v in enumerate(counts.values):
    axes[0, 0].text(i, v + 5, str(v), ha="center", fontsize=10)

# Plot 2: Churn rate by tenure group
churn_by_tenure.plot(kind="bar", ax=axes[0, 1], color="#e34948", rot=0)
axes[0, 1].set_title("Churn Rate by Tenure Group (%)")
axes[0, 1].set_ylabel("Churn Rate (%)")
axes[0, 1].set_xlabel("")

# Plot 3: Monthly charges by churn status
axes[1, 0].hist(df[df["churn_bin"] == 0]["monthly_charge_inr"], bins=20,
                alpha=0.6, color="#2a78d6", label="Retained")
axes[1, 0].hist(df[df["churn_bin"] == 1]["monthly_charge_inr"], bins=20,
                alpha=0.6, color="#e34948", label="Churned")
axes[1, 0].set_title("Monthly Charges: Retained vs Churned (INR)")
axes[1, 0].set_xlabel("Monthly Charge (Rs)")
axes[1, 0].legend()

# Plot 4: Top 8 features
top8 = importances.head(8)
axes[1, 1].barh(top8.index[::-1], top8.values[::-1], color="#1baf7a")
axes[1, 1].set_title("Top 8 Features Correlated with Churn")
axes[1, 1].set_xlabel("Importance Score")

plt.tight_layout()
plt.savefig("churn_dashboard.png", dpi=150, bbox_inches="tight")
plt.close()
print("\nDashboard saved: churn_dashboard.png")

# ── 5. BUSINESS INSIGHTS ──────────────────────────────────────────────────────
print(f"\n=== KEY INSIGHTS FOR STAKEHOLDERS ===")
print(f"1. Overall churn rate: {churn_rate:.1f}%")
print(f"2. Monthly revenue at risk: Rs {monthly_rev_at_risk:,.0f}")
print(f"3. Prepaid monthly contract churn rate: {churn_by_contract['Prepaid Monthly']:.1f}% vs Annual Plan {churn_by_contract['Annual Plan']:.1f}%")
print(f"4. Customers in first 12 months have highest churn: {churn_by_tenure.iloc[0]:.1f}%")
print(f"5. Best model ROC-AUC: {max(lr_auc, rf_auc):.3f}")
