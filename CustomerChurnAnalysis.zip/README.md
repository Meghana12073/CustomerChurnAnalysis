# Customer Churn Analysis and BI Dashboard

End-to-end churn analysis on Indian telecom data: EDA, feature engineering, classification modelling, and a 4 panel stakeholder dashboard.

## Business Problem
Telecom companies lose recurring revenue every time a customer churns. This project identifies at-risk customers and the key drivers of churn in the Indian market.

## Key Findings
| Metric | Value |
|---|---|
| Dataset size | 1,000 customers |
| Overall churn rate | 11.2% |
| Monthly revenue at risk | Rs 66,248 |
| Prepaid monthly churn rate | 11.8% vs 10.5% annual plan |
| Best model ROC-AUC | 0.992 (Random Forest) |

## How to Run
```bash
pip install -r requirements.txt
python generate_data.py
python churn_analysis.py
```

## Skills Demonstrated
EDA, data cleaning, LabelEncoder, feature engineering, Logistic Regression, Random Forest, confusion matrix, ROC-AUC, 4 panel Matplotlib dashboard

**Author:** Meghana N | B.E. CSE, Vemana Institute of Technology (2026)
